# Human-Centred, Citation-Audited Springer Nature Package

This package contains the revised manuscript, bibliography, figures, compilation files, detailed revision prompt, citation audit, and compiled PDF.

The AI-writing report marked 35%, but it also warns about false positives. The similarity report showed 2% after bibliography and quotations were filtered. This revision improves authentic authorship and citation integrity; it does not guarantee a detector score.

## Overleaf
1. New Project -> Upload Project
2. Upload this ZIP
3. Select main.tex
4. Select pdfLaTeX
5. Recompile from scratch

Before submission, both authors should verify every DOI, result, author contribution, and disclosure statement.
