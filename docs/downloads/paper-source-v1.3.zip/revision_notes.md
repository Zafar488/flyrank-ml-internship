# Revision Notes

The paper was revised for authentic authorship, academic clarity, and citation integrity.

Changes include:
- full prose revision of the abstract, introduction, related work, methods explanations, results interpretation, limitations, and conclusion;
- replacement of formulaic transitions and repetitive sentence patterns;
- preservation of equations, tables, figures, model settings, and verified metrics;
- clearer separation of observed findings, interpretation, and causal limits;
- stronger explanation of grouped validation and availability-time leakage;
- more precise claim-level citations;
- transparent retention of the generative-AI disclosure.

No word spinning, hidden characters, deliberate grammar errors, or detector-evasion methods were used. No detector result can be guaranteed. Both authors must read, edit, and approve the final text.
