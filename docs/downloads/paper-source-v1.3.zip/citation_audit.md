# Citation and Similarity Audit

## Uploaded-report findings

The AI-writing report marks 35% of the prose as likely AI-generated, while also warning that the assessment can produce false positives and should not be used alone for an academic decision.

The separate similarity report shows 2% overall similarity after bibliography and quoted text were filtered. It lists six small matches as not cited or quoted, one near-verbatim match under missing quotation at less than 1%, zero missing-citation matches, and zero integrity flags. Individual listed sources contribute less than 1% each.

The paper therefore was not revised toward an arbitrary 10-14% target. The revision focuses on original synthesis, claim-level support, and transparent authorship.

## Repairs applied

- Related work was reorganized by research problem instead of repetitive one-paper summaries.
- Citations were placed next to the specific claims they support.
- Direct SEO evidence was separated from leakage, grouped-validation, ranking, and human-review analogies.
- Data and repository references were used only for provenance and reproducibility.
- The stock software-version sentence was replaced by a concise environment description linked to the repository receipt.
- Distinctive or formulaic wording was rewritten from the study's own decisions and evidence.
- No long direct quotations remain.
- The gap is framed as limited evidence rather than an absolute absence of prior work.
- Planned experiments remain in Future Work and are not presented as completed results.

## Author checks

- Verify every DOI and final publication record.
- Confirm all numerical values against the latest aggregate receipts.
- Confirm the author-contribution statement.
- Confirm the target journal's generative-AI disclosure policy.
- Rewrite any sentence that neither author would naturally use or defend.
